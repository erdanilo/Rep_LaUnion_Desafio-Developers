use DBZ
go


-- Escribe una consulta en la que debes crear una variable tipo tabla o tabla temporal, esta debe ser una copia de la tabla TPersonajes, en esta variable tipo tabla debes  actualizar el valor de Ki y maxKi a n�mero. 
-- Esta te servir� para operar realizar los queries que utilizan dichas columnas. (Valor: 10%)
-- Columna MaxKi
----------------------------------------------------------------------------------------------------------------------------
declare @TablaFinal as table
(
	id int
	,name varchar(200)
	,ki varchar(500)
	,maxKi varchar(500)
	,race nvarchar(200)
	,kiNumerico numeric(38,0)
	,maxKiNumerico numeric(38,0)
);

-- billion
with TablaBillion (id,name,ki,maxKi,race,maxKiSinTexto) AS (
	SELECT
		id
		,name
		,ki
		,maxKi
		,race
		,Convert(NUMERIC(38, 0),REPLACE(maxKi, ' billion', ''))	as maxKiSinTexto
	FROM [DBZ].[dbo].[TPersonaje]
	where maxKi like '%billion%'
)

insert into @TablaFinal
SELECT
	id
	,name
	,ki
	,maxKi
	,race
	,0
    ,maxKiSinTexto * 1000000000 AS maxKiNumerico
FROM TablaBillion;


-- trillion
with TablaTrillion (id,name,ki,maxKi,race,maxKiSinTexto) AS (
	SELECT
		id
		,name
		,ki
		,maxKi
		,race
		,Convert(NUMERIC(38, 0),REPLACE(maxKi, ' trillion', ''))	as maxKiSinTexto
	FROM [DBZ].[dbo].[TPersonaje]
	where maxKi like '%trillion%'
)

insert into @TablaFinal
SELECT
	id
	,name
	,ki
	,maxKi
	,race
	,0
    ,maxKiSinTexto * 1000000000000 AS maxKiNumerico
FROM TablaTrillion;


-- quintillion
with TablaQuintillion (id,name,ki,maxKi,race,maxKiSinTexto) AS (
	SELECT
		id
		,name
		,ki
		,maxKi
		,race
		,Convert(NUMERIC(38, 0),REPLACE(maxKi, ' quintillion', ''))	as maxKiSinTexto
	FROM [DBZ].[dbo].[TPersonaje]
	where maxKi like '%quintillion%'
)

insert into @TablaFinal
SELECT
	id
	,name
	,ki
	,maxKi
	,race
	,0
    ,maxKiSinTexto * 1000000000000000000 AS maxKiNumerico
FROM TablaQuintillion;


-- sextillion
with TablaSextillion (id,name,ki,maxKi,race,maxKiSinTexto) AS (
	SELECT
		id
		,name
		,ki
		,maxKi
		,race
		,Convert(NUMERIC(38, 0),REPLACE(maxKi, ' sextillion', ''))	as maxKiSinTexto
	FROM [DBZ].[dbo].[TPersonaje]
	where maxKi like '%sextillion%'
)

insert into @TablaFinal
SELECT
	id
	,name
	,ki
	,maxKi
	,race
	,0
    ,maxKiSinTexto * 1000000000000000000000 AS maxKiNumerico
FROM TablaSextillion;



-- septillion
with TablaSeptillion (id,name,ki,maxKi,race,maxKiSinTexto) AS (
	SELECT
		id
		,name
		,ki
		,maxKi
		,race
		,Convert(NUMERIC(38, 0),REPLACE(maxKi, ' Septillion', ''))	as maxKiSinTexto
	FROM [DBZ].[dbo].[TPersonaje]
	where maxKi like '%Septillion%'
)

insert into @TablaFinal
SELECT
	id
	,name
	,ki
	,maxKi
	,race
	,0
    ,maxKiSinTexto * 1000000000000000000000000 AS maxKiNumerico
FROM TablaSeptillion;


-- septllion
with TablaSeptllion (id,name,ki,maxKi,race,maxKiSinTexto) AS (
	SELECT
		id
		,name
		,ki
		,maxKi
		,race
		,Convert(NUMERIC(38, 0),REPLACE(maxKi, ' Septllion', ''))	as maxKiSinTexto
	FROM [DBZ].[dbo].[TPersonaje]
	where maxKi like '%Septllion%'
)

insert into @TablaFinal
SELECT
	id
	,name
	,ki
	,maxKi
	,race
	,0
    ,maxKiSinTexto * 1000000000000000000000000 AS maxKiNumerico
FROM TablaSeptllion;



-- googolplex, voy a utilizar el valor maximo de numeric que es 38 porque es demasiado grande ese numero
with TablaGoogolplex (id,name,ki,maxKi,race,maxKiSinTexto) AS (
	SELECT
		id
		,name
		,ki
		,maxKi
		,race
		,Convert(NUMERIC(38, 0),REPLACE(maxKi, ' googolplex', ''))	as maxKiSinTexto
	FROM [DBZ].[dbo].[TPersonaje]
	where maxKi like '%googolplex%'
)

insert into @TablaFinal
SELECT
	id
	,name
	,ki
	,maxKi
	,race
	,0
    ,maxKiSinTexto * 100000000000000000000000000000000000 AS maxKiNumerico
FROM TablaGoogolplex;


-- obtener solo los numeros
with TablaNumeros (id,name,ki,maxKi,race,maxKiSinTexto) AS (
select id
		,name
		,ki
		,maxKi
		,race
		,convert(numeric(38,0),replace(maxKiReplace,',','')) as maxKiSinTexto
from (
	SELECT
		id
		,name
		,ki
		,maxKi
		,race
		,replace(maxKi,'.','') as maxKiReplace
	FROM [DBZ].[dbo].[TPersonaje]
	where maxKi != 'unknown'
	 and id not in (select id from @TablaFinal)
 ) as t
)

insert into @TablaFinal
SELECT
	id
	,name
	,ki
	,maxKi
	,race
	,0
    ,maxKiSinTexto
FROM TablaNumeros;
----------------------------------------------------------------

-- Columna Ki
----------------------------------------------------------------
-- billion
with TablaBillion (id,name,ki,maxKi,race,KiNumerico) AS (
select 
	id
	,name
	,ki
	,maxKi
	,race
	,KiSinTexto * 1000000000 AS KiNumerico
from (
	SELECT
		id
		,name
		,ki
		,maxKi
		,race
		,Convert(NUMERIC(38, 0),REPLACE(ki, ' billion', ''))	as KiSinTexto
	FROM [DBZ].[dbo].[TPersonaje]
	where ki like '%billion%'
 ) as t
)

update tf
set kiNumerico = tb.KiNumerico
from @TablaFinal			as tf
 inner join TablaBillion	as tb on (tf.id = tb.id);


-- trillion
with TablaTrillion (id,name,ki,maxKi,race,KiNumerico) AS (
select 
	id
	,name
	,ki
	,maxKi
	,race
	,KiSinTexto * 1000000000000 AS KiNumerico
from (
	SELECT
		id
		,name
		,ki
		,maxKi
		,race
		,Convert(NUMERIC(38, 0),REPLACE(ki, ' trillion', ''))	as KiSinTexto
	FROM [DBZ].[dbo].[TPersonaje]
	where ki like '%trillion%'
 ) as t
)

update tf
set kiNumerico = tb.KiNumerico
from @TablaFinal			as tf
 inner join TablaTrillion	as tb on (tf.id = tb.id);

-- quadrillion
with TablaQuadrillion (id,name,ki,maxKi,race,KiNumerico) AS (
select 
	id
	,name
	,ki
	,maxKi
	,race
	,KiSinTexto * 1000000000000000 AS KiNumerico
from (
	SELECT
		id
		,name
		,ki
		,maxKi
		,race
		,Convert(NUMERIC(38, 0),REPLACE(ki, ' quadrillion', ''))	as KiSinTexto
	FROM [DBZ].[dbo].[TPersonaje]
	where ki like '%quadrillion%'
 ) as t
)

update tf
set kiNumerico = tb.KiNumerico
from @TablaFinal			as tf
 inner join TablaQuadrillion	as tb on (tf.id = tb.id);


-- quintillion
with TablaQuintillion (id,name,ki,maxKi,race,KiNumerico) AS (
select 
	id
	,name
	,ki
	,maxKi
	,race
	,KiSinTexto * 1000000000000000000 AS KiNumerico
from (
	SELECT
		id
		,name
		,ki
		,maxKi
		,race
		,Convert(NUMERIC(38, 0),REPLACE(ki, ' quintillion', ''))	as KiSinTexto
	FROM [DBZ].[dbo].[TPersonaje]
	where ki like '%quintillion%'
 ) as t
)

update tf
set kiNumerico = tb.KiNumerico
from @TablaFinal			as tf
 inner join TablaQuintillion	as tb on (tf.id = tb.id);

-- septillion
with TablaSeptillion (id,name,ki,maxKi,race,KiNumerico) AS (
select 
	id
	,name
	,ki
	,maxKi
	,race
	,KiSinTexto * 1000000000000000000000000 AS KiNumerico
from (
	SELECT
		id
		,name
		,ki
		,maxKi
		,race
		,Convert(NUMERIC(38, 0),REPLACE(ki, ' Septillion', ''))	as KiSinTexto
	FROM [DBZ].[dbo].[TPersonaje]
	where ki like '%Septillion%'
 ) as t
)

update tf
set kiNumerico = tb.KiNumerico
from @TablaFinal			as tf
 inner join TablaSeptillion	as tb on (tf.id = tb.id);

-- googolplex, voy a utilizar el valor maximo de numeric que es 38 porque es demasiado grande ese numero
with TablaGoogolplex (id,name,ki,maxKi,race,KiNumerico) AS (
select 
	id
	,name
	,ki
	,maxKi
	,race
	,KiSinTexto * 100000000000000000000000000000000000 AS KiNumerico
from (
	SELECT
		id
		,name
		,ki
		,maxKi
		,race
		,Convert(NUMERIC(38, 0),REPLACE(ki, ' googolplex', ''))	as KiSinTexto
	FROM [DBZ].[dbo].[TPersonaje]
	where ki like '%googolplex%'
 ) as t
)

update tf
set kiNumerico = tb.KiNumerico
from @TablaFinal			as tf
 inner join TablaGoogolplex	as tb on (tf.id = tb.id);


-- obtener solo los numeros
with TablaNumeros (id,kiNumerico) AS (
select id
		,convert(numeric(38,0),replace(KiReplace,',','')) as kiNumerico
from (
	SELECT
		id
		,replace(Ki,'.','') as KiReplace
	FROM @TablaFinal
	where kiNumerico = 0
 ) as t
)


update tf
set kiNumerico = tb.KiNumerico
from @TablaFinal			as tf
 inner join TablaNumeros	as tb on (tf.id = tb.id);

select *
from @TablaFinal
----------------------------------------------------------------------------------------------------------------------------


-- Escribe una consulta que devuelva la brecha que hay entre Ki y maxKi de cada personaje y ordena el resultado ascendentemente por esta brecha. (Valor: 10%) 
----------------------------------------------------------------------------------------------------------------------------
select  Personaje
		,kiNumerico
		,maxKiNumerico
		,Brecha
from (
	select	name						as Personaje
			,kiNumerico
			,maxKiNumerico
			,maxKiNumerico - kiNumerico	as Brecha
	from @TablaFinal
) as t
order by Brecha asc;
----------------------------------------------------------------------------------------------------------------------------


-- Escribe una consulta que retorne el personaje m�s poderoso por cada raza (Valor: 10%)
----------------------------------------------------------------------------------------------------------------------------
with tablaTemporal as(
select	race
		,name
		,maxKiNumerico
from @TablaFinal as t
)

select race		as Raza
		,name	as Personaje
		,maxKiNumerico
from tablaTemporal as t
where exists (
	select race, maximo
	from (
		select race, max(maxKiNumerico) as maximo
		from tablaTemporal
		group by race
	) as e
	where e.race = t.race and e.maximo = t.maxKiNumerico
)
order by Raza
----------------------------------------------------------------------------------------------------------------------------


-- Escribe una consulta que retorne al dios m�s d�bil. (Valor: 10%)
----------------------------------------------------------------------------------------------------------------------------
select *
from @TablaFinal
where maxKiNumerico = (
	select min(maxKiNumerico) minKi
	from @TablaFinal
	where race = 'God'
)
----------------------------------------------------------------------------------------------------------------------------