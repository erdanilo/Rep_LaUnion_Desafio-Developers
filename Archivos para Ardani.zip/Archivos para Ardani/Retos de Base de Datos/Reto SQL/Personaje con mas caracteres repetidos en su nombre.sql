use DBZ
go


-- Crea una consulta que retorne los personajes con m�s caracteres repetidos en su nombre. 
-- Muestra las siguientes columnas: nombre, la cantidad de letras repetidas en su nombre y el detalle de las repeticiones. (Valor: 15%)
----------------------------------------------------------------------------------------------------------------------------
Declare @TablaPersonaje as table
(
	id		int,
	name	nvarchar(200)
)

insert into @TablaPersonaje
select	id, name from TPersonaje

Declare @TablaTemporalFinal as table
(
	Nombre					nvarchar(200),
	ConteoLetrasRepetidas	int,
	Detalle					nvarchar(200)
)

Declare @TablaFrecuencia as table
(
	Letra		nvarchar(100),
	Frecuencia	int
)

declare @Contador						int
		,@ConteroDeRegistrosAProcesar	int
		,@IdMinimo						int
		,@Personaje						nvarchar(200)
		,@contadorLista					int
		,@contadorDetalle				int
		,@conteoLetrasRepetidas			int
		,@letraMinima					nvarchar(50)
		,@cadenaLetrasRepetidas			nvarchar(200)
		,@letra							nvarchar(50)
		,@frecuencia					int
		,@conteoTablaFrecuencia			int

set @ConteroDeRegistrosAProcesar = (select COUNT(*) from @TablaPersonaje)
--Contador para ir pasando a procesar el siguiente registro
set @Contador = 1


while @Contador <= @ConteroDeRegistrosAProcesar
begin
	set @IdMinimo = 0
	set @Personaje = null
	set @conteoLetrasRepetidas = 0

	--Selecciono minimo Id de la tabla temporal
	select	@IdMinimo = min(id)
	from @TablaPersonaje

	--Ahora selecciono ese registro con Id minimo para obtener los datos
	select	@Personaje = RTrim(LTrim(name))
	from @TablaPersonaje
	where id = @IdMinimo

	-- Obtengo la frecuencia de letras
	------------------------------------------------------------
	set @contadorLista = 1

	declare @tablaLista as table
	(
		numero int
	)

	while @contadorLista <= len(@Personaje)
	begin
		insert into @tablaLista values(@contadorLista)
		set @contadorLista = @contadorLista + 1
	end;

	WITH tablaPalabras (palabra) AS (
		select @Personaje
	),

	tablaLetras (letra) AS (
		SELECT SUBSTRING(palabra, i, 1) AS letra
		FROM tablaPalabras
		CROSS JOIN (
			SELECT ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS i
			FROM tablaPalabras
			CROSS JOIN ( select * from @tablaLista ) AS listaNumerica
		) AS i
	)
	
	insert into @TablaFrecuencia
	SELECT	letra
			,COUNT(*) AS frecuencia
	FROM tablaLetras
	GROUP BY letra

	select @conteoLetrasRepetidas = isnull(sum(frecuencia),0)
	from @TablaFrecuencia
	where frecuencia > 1
	and Letra != ' '
	------------------------------------------------------------

	set @cadenaLetrasRepetidas = ''
	set @contadorDetalle = 1
	set @conteoTablaFrecuencia = (select COUNT(*) from @TablaFrecuencia)
	while @contadorDetalle <= @conteoTablaFrecuencia
	begin		
		select @letraMinima = min(Letra)
		from @TablaFrecuencia	
				
		select	@letra = Letra
				,@frecuencia = Frecuencia
		from @TablaFrecuencia
		where Letra = @letraMinima

		if(@frecuencia >= 2 and (@letra != ' '))
		begin
			set @cadenaLetrasRepetidas = @letra +':'+ convert(varchar(50),@frecuencia) + ', '+@cadenaLetrasRepetidas
		end

		delete
		from @TablaFrecuencia
		where Letra = @letraMinima

		set @contadorDetalle = @contadorDetalle + 1
	end;

	-- Agrego el detalle a la tabla final
	insert into @TablaTemporalFinal values(@Personaje,@conteoLetrasRepetidas,@cadenaLetrasRepetidas)
		
	delete @TablaFrecuencia
	delete @tablaLista

	--Borramos el Id minimo que estamos procesando de la tabla temporal, para que nos queden solo los que falta procesar
	delete
	from @TablaPersonaje
	where id = @IdMinimo

	--Incremento el contador para procesar el siguiente registro
	set @Contador = @Contador + 1
end


select * from @TablaTemporalFinal
where ConteoLetrasRepetidas >= 2
order by ConteoLetrasRepetidas desc

delete @TablaTemporalFinal
----------------------------------------------------------------------------------------------------------------------------