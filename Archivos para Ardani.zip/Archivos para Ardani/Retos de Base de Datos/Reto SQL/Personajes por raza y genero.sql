use DBZ
go


-- Escribe una consulta que devuelva el conteo de personajes por raza y g�nero. (Valor: 15%)
----------------------------------------------------------------------------------------------------------------------------
select	race
		,sum(Masculino)	as Masculino
		,sum(Femenino)	as Femenino
from 
(
select	race
		,case when gender = 'Male' then count(gender)
			  else ''
		 end	as Masculino
		,case when gender = 'FeMale' then count(gender)
			  else ''
		 end	as Femenino
from [DBZ].[dbo].[TPersonaje]
group by race, gender
) as t
group by race
----------------------------------------------------------------------------------------------------------------------------