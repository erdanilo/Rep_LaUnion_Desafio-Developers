use DBZ
go


-- Escribe una consulta que muestre el nombre de cada personaje y su nombre inverso, por ejemplo: Kamisama, amasimak (Valor: 10%)
----------------------------------------------------------------------------------------------------------------------------
select	name			as Nombre
		,REVERSE(name)	as NombreInverso
from [DBZ].[dbo].[TPersonaje]
----------------------------------------------------------------------------------------------------------------------------