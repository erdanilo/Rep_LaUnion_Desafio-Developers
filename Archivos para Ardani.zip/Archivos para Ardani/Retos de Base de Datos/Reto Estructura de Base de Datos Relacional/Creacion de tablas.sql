use dbDesafio
go


create table dbo.MEDKITUsuario
(
	IdUsuario int not null
	,Usuario nvarchar(100) not null
	,NombreUsuario nvarchar(500) not null
	,ClaveUsuario nvarchar(100) not null
	,UsuarioInserto nvarchar(100) not null
	,FechaInserto datetime not null
	,UsuarioModifico nvarchar(100)
	,FechaModifico datetime
	,Eliminado bit not null
)

alter table dbo.MEDKITUsuario
add constraint Usuario_PK primary key(IdUsuario)

alter table dbo.MEDKITUsuario
add constraint Usuario_Eliminado_DF default 0 for Eliminado


create table dbo.MEDKITLuchador
(
	IdLuchador int not null
	,NombreLuchador nvarchar(500) not null
	,CorreoLuchador nvarchar(500)
	,UsuarioInserto nvarchar(100) not null
	,FechaInserto datetime not null
	,UsuarioModifico nvarchar(100)
	,FechaModifico datetime
	,Eliminado bit not null
)

alter table dbo.MEDKITLuchador
add constraint Luchador_PK primary key(IdLuchador)

alter table dbo.MEDKITLuchador
add constraint Luchador_Eliminado_DF default 0 for Eliminado


create table dbo.MEDKITPersonaje
(
	IdPersonaje int not null
	,NombrePersonaje nvarchar(500) not null
	,PoderInicio int not null
	,PoderFin int not null
	,UsuarioInserto nvarchar(100) not null
	,FechaInserto datetime not null
	,UsuarioModifico nvarchar(100)
	,FechaModifico datetime
	,Eliminado bit not null
)

alter table dbo.MEDKITPersonaje
add constraint Personaje_PK primary key(IdPersonaje)

alter table dbo.MEDKITPersonaje
add constraint Personaje_Eliminado_DF default 0 for Eliminado


create table dbo.MEDKITCategoria
(
	IdCategoria int not null
	,NombreCategoria nvarchar(500) not null
	,UsuarioInserto nvarchar(100) not null
	,FechaInserto datetime not null
	,UsuarioModifico nvarchar(100)
	,FechaModifico datetime
	,Eliminado bit not null
)

alter table dbo.MEDKITCategoria
add constraint Categoria_PK primary key(IdCategoria)

alter table dbo.MEDKITCategoria
add constraint Categoria_Eliminado_DF default 0 for Eliminado


create table dbo.MEDKITReto
(
	IdReto int not null
	,NombreReto nvarchar(500) not null
	,IdCategoria int not null
	,UsuarioInserto nvarchar(100) not null
	,FechaInserto datetime not null
	,UsuarioModifico nvarchar(100)
	,FechaModifico datetime
	,Eliminado bit not null
)

alter table dbo.MEDKITReto
add constraint Reto_PK primary key(IdReto)

alter table dbo.MEDKITReto
add constraint Reto_Eliminado_DF default 0 for Eliminado

alter table dbo.MEDKITReto
add constraint Categoria_Reto_FK foreign key(IdCategoria) references dbo.MEDKITCategoria(IdCategoria)



-- Relaciones

create table dbo.MEDKITLuchadorPersonaje
(
	IdLuchadorPersonaje int not null
	,IdLuchador int not null
	,IdPersonaje int not null
	,Ki decimal
	,Esferas int
	,UsuarioInserto nvarchar(100) not null
	,FechaInserto datetime not null
	,UsuarioModifico nvarchar(100)
	,FechaModifico datetime
	,Activo bit not null
	,Eliminado bit not null
)

alter table dbo.MEDKITLuchadorPersonaje
add constraint LuchadorPersonaje_PK primary key(IdLuchadorPersonaje)

alter table dbo.MEDKITLuchadorPersonaje
add constraint Luchador_LuchadorPersonaje_FK foreign key(IdLuchador) references dbo.MEDKITLuchador(IdLuchador)

alter table dbo.MEDKITLuchadorPersonaje
add constraint Personaje_LuchadorPersonaje_FK foreign key(IdPersonaje) references dbo.MEDKITPersonaje(IdPersonaje)

alter table dbo.MEDKITLuchadorPersonaje
add constraint LuchadorPersonaje_Activo_DF default 1 for Activo

alter table dbo.MEDKITLuchadorPersonaje
add constraint LuchadorPersonaje_Eliminado_DF default 0 for Eliminado


create table dbo.MEDKITCalificacion
(
	IdCalificacion int not null
	,IdLuchadorPersonaje int not null
	,IdReto int not null
	,Puntaje decimal not null
	,UsuarioInserto nvarchar(100) not null
	,FechaInserto datetime not null
	,UsuarioModifico nvarchar(100)
	,FechaModifico datetime
	,Activo bit not null
	,Eliminado bit not null
)

alter table dbo.MEDKITCalificacion
add constraint Calificacion_PK primary key(IdCalificacion)

alter table dbo.MEDKITCalificacion
add constraint Calificacion_Activo_DF default 1 for Activo

alter table dbo.MEDKITCalificacion
add constraint Calificacion_Eliminado_DF default 0 for Eliminado

alter table dbo.MEDKITCalificacion
add constraint Calificacion_LuchadorPersonaje_FK foreign key(IdLuchadorPersonaje) references dbo.MEDKITLuchadorPersonaje(IdLuchadorPersonaje)

alter table dbo.MEDKITCalificacion
add constraint Calificacion_Reto_FK foreign key(IdReto) references dbo.MEDKITReto(IdReto)